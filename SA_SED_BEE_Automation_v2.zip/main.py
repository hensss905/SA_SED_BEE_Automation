from modules.scraper import get_fortune500_sa, filter_sed_bee
from modules.contact_collector import collect_contacts
from modules.ai_autoreply import ai_reply
from modules.crm import add_lead
from config import MESSAGE_TEMPLATE

def main():
    df = get_fortune500_sa()
    filtered_df = filter_sed_bee(df)
    
    with open(MESSAGE_TEMPLATE, "r") as f:
        message_body = f.read()
    
    for idx, row in filtered_df.iterrows():
        company = row['company_name']
        contacts = collect_contacts(company)
        for c in contacts:
            reply = ai_reply(c['name'], company, message_body)
            add_lead(c['name'], c['email'], c.get('linkedin', None), reply)
            print(f"Collected lead: {c['name']} at {company}")

if __name__ == "__main__":
    main()
