# SA_SED_BEE_Automation_v2
Automated SED/BEE lead collection system for SA companies with AI auto-reply to schedule meetings.