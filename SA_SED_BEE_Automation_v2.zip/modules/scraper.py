import pandas as pd

def get_fortune500_sa():
    # Load example CSV or scrape actual Fortune 500 in SA
    df = pd.read_csv("examples/sample_companies.csv")
    return df

def filter_sed_bee(df):
    df_filtered = df[df['website_content'].str.contains("SED|BEE|CSR", case=False)]
    return df_filtered
