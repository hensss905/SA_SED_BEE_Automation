import csv
import os

CRM_FILE = "logs/leads.csv"

def add_lead(name, email, linkedin, reply_status):
    # Save leads to CSV
    file_exists = os.path.isfile(CRM_FILE)
    with open(CRM_FILE, mode='a', newline='') as file:
        writer = csv.writer(file)
        if not file_exists:
            writer.writerow(["Name", "Email", "LinkedIn", "ReplyStatus"])
        writer.writerow([name, email, linkedin, reply_status])
