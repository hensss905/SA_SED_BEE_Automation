from config import AI_REPLY_MODEL, AI_REPLY_PROMPT

def ai_reply(contact_name, company_name, message_body):
    # Placeholder AI auto-reply (replace with OpenAI API call if available)
    reply = f"Hello {contact_name}, thank you for your interest. We would love to discuss SED/BEE projects with {company_name}. Please schedule a meeting with Henlo Pulzone."
    return reply
